// import React from "react";

// export default function EmployerResume() {
//   return (
//     <>
    
//         <div class="twm-right-section-panel candidate-save-job site-bg-light">
//           <div class="twm-candidates-grid-wrap">
//             <h5>Your shopspot referral point balance</h5>

//             <div class="twm-candidates-grid-style1 mb-5 mt-4 pt-0">
//               <div class="twm-fot-content" style={{ borderRadius: '10px' }}>
//                 <div class="twm-left-info">
//                   <p class="twm-candidate-address">
//                     <i class="fa fa-user"></i>Referral points
//                   </p>
//                   <div class="twm-jobs-vacancies">
//                     <a href="Refer&Earn-Point.html" class="twm-job-title">
//                       <div class="twm-jobs-vacancies">
//                         <span>100 points</span>
//                       </div>
//                     </a>
//                   </div>
//                 </div>
//               </div>
//             </div>
//             <div class="twm-candidates-grid-style1 mb-5 mt-4 pt-0">
//               <div class="twm-fot-content" style={{ borderRadius: '10px' }}>
//                 <div class="twm-left-info flex-column text-start">
//                   <span class="twm-candidate-address text-secondary">
//                     What you get?
//                   </span>
//                   <h5>Get exciting rewards on their sign up</h5>
//                   <p class="twm-candidate-address text-secondary">
//                     Share your refrel link with your friends and when they their
//                     sign up you’ll both get shopspot 100 points
//                   </p>
//                 </div>
//               </div>
//             </div>
//             <div class="twm-candidates-grid-style1 mb-5 mt-4 pt-0">
//               <div class="twm-fot-content" style={{ borderRadius: '10px' }}>
//                 <div class="twm-left-info">
//                   <div class="text-start">
//                     <p class="twm-candidate-address text-secondary">
//                       Share your referral code
//                     </p>
//                     <h4 class="twm-candidate-address">DRTF70FW</h4>
//                   </div>
//                   <div class="twm-jobs-vacancies">
//                     <a href="#" class="twm-job-title">
//                       <div class="twm-jobs-vacancies">
//                         <span>
//                           <img src="images/Vector (3).svg" alt="" />
//                         </span>
//                       </div>
//                     </a>
//                     <a href="#" class="twm-job-title">
//                       <div class="twm-jobs-vacancies">
//                         <span>
//                           <i class="fas fa-share-alt"></i>
//                         </span>
//                       </div>
//                     </a>
//                   </div>
//                 </div>
//               </div>
//             </div>
//             <div class="row">
//               <div class="col-lg-12 text-end">
//                 <button type="submit" class="site-button m-r5">
//                   Share with contact
//                 </button>
//               </div>
//             </div>
//             <h5>Frequently asked questions</h5>

//             <div class="accordion" id="Refer&Earn">
//               <div class="accordion-item">
//                 <h2 class="accordion-header">
//                   <button
//                     class="accordion-button text-dark"
//                     type="button"
//                     data-bs-toggle="collapse"
//                     data-bs-target="#Refer&Earn1"
//                     aria-expanded="true"
//                     aria-controls="Refer&Earn1"
//                   >
//                     How do i use shopspot points
//                   </button>
//                 </h2>
//                 <div
//                   id="Refer&Earn1"
//                   class="accordion-collapse collapse show"
//                   data-bs-parent="#Refer&Earn"
//                 >
//                   <div class="accordion-body">
//                     Lorem ipsum dolor sit amet, consectetur adipiscing elit.
//                     Morbi ullamcorper rhoncus tellus
//                   </div>
//                 </div>
//               </div>
//               <div class="accordion-item">
//                 <h2 class="accordion-header">
//                   <button
//                     class="accordion-button text-dark collapsed"
//                     type="button"
//                     data-bs-toggle="collapse"
//                     data-bs-target="#Refer&Earn2"
//                     aria-expanded="false"
//                     aria-controls="Refer&Earn2"
//                   >
//                     How can i invite friends?
//                   </button>
//                 </h2>
//                 <div
//                   id="Refer&Earn2"
//                   class="accordion-collapse collapse"
//                   data-bs-parent="#Refer&Earn"
//                 >
//                   <div class="accordion-body">
//                     Lorem ipsum dolor sit amet, consectetur adipiscing elit.
//                     Morbi ullamcorper rhoncus tellus
//                   </div>
//                 </div>
//               </div>
//               <div class="accordion-item">
//                 <h2 class="accordion-header">
//                   <button
//                     class="accordion-button text-dark collapsed"
//                     type="button"
//                     data-bs-toggle="collapse"
//                     data-bs-target="#Refer&Earn3"
//                     aria-expanded="false"
//                     aria-controls="Refer&Earn3"
//                   >
//                     Is there any expiry date for shopspot points?
//                   </button>
//                 </h2>
//                 <div
//                   id="Refer&Earn3"
//                   class="accordion-collapse text-dark collapse"
//                   data-bs-parent="#Refer&Earn"
//                 >
//                   <div class="accordion-body">
//                     Lorem ipsum dolor sit amet, consectetur adipiscing elit.
//                     Morbi ullamcorper rhoncus tellus
//                   </div>
//                 </div>
//               </div>
//               <div class="accordion-item">
//                 <h2 class="accordion-header">
//                   <button
//                     class="accordion-button text-dark collapsed"
//                     type="button"
//                     data-bs-toggle="collapse"
//                     data-bs-target="#Refer&Earn4"
//                     aria-expanded="false"
//                     aria-controls="Refer&Earn4"
//                   >
//                     How can i invite friends?
//                   </button>
//                 </h2>
//                 <div
//                   id="Refer&Earn4"
//                   class="accordion-collapse collapse"
//                   data-bs-parent="#Refer&Earn"
//                 >
//                   <div class="accordion-body">
//                     Lorem ipsum dolor sit amet, consectetur adipiscing elit.
//                     Morbi ullamcorper rhoncus tellus
//                   </div>
//                 </div>
//               </div>
//               <div class="accordion-item">
//                 <h2 class="accordion-header">
//                   <button
//                     class="accordion-button text-dark collapsed"
//                     type="button"
//                     data-bs-toggle="collapse"
//                     data-bs-target="#Refer&Earn5"
//                     aria-expanded="false"
//                     aria-controls="Refer&Earn5"
//                   >
//                     Is there any expiry date for shopspot points?
//                   </button>
//                 </h2>
//                 <div
//                   id="Refer&Earn5"
//                   class="accordion-collapse collapse"
//                   data-bs-parent="#Refer&Earn"
//                 >
//                   <div class="accordion-body">
//                     Lorem ipsum dolor sit amet, consectetur adipiscing elit.
//                     Morbi ullamcorper rhoncus tellus
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>

//           <div class="pagination-outer">
//             <div class="pagination-style1">
//               <ul class="clearfix">
//                 <li class="prev">
//                   <a href="javascript:;">
//                     <span>
//                       {" "}
//                       <i class="fa fa-angle-left"></i>{" "}
//                     </span>
//                   </a>
//                 </li>
//                 <li>
//                   <a href="javascript:;">1</a>
//                 </li>
//                 <li class="active">
//                   <a href="javascript:;">2</a>
//                 </li>
//                 <li>
//                   <a href="javascript:;">3</a>
//                 </li>
//                 <li>
//                   <a class="javascript:;" href="javascript:;">
//                     <i class="fa fa-ellipsis-h"></i>
//                   </a>
//                 </li>
//                 <li>
//                   <a href="javascript:;">5</a>
//                 </li>
//                 <li class="next">
//                   <a href="javascript:;">
//                     <span>
//                       {" "}
//                       <i class="fa fa-angle-right"></i>{" "}
//                     </span>
//                   </a>
//                 </li>
//               </ul>
//             </div>
//           </div>
//         </div>
      
//     </>
//   );
// }
